package com.example.opsc7312poe_navigation_app;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.firebase.client.Firebase;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class activity_recent extends AppCompatActivity{
    ListView listRecent;
    private FirebaseAuth mAuth;
    private Firebase mRef;
    private String trips;
    private User user1;
    FirebaseDatabase mDB;
    DatabaseReference mDBRef ;
    Trip[] arrTrips;

    DatabaseReference mRootRef = FirebaseDatabase.getInstance().getReference();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recent);
        BottomNavigationView bottomNavigationView = findViewById(R.id.btm_nav);
listRecent = findViewById(R.id.listRecent);
        mAuth = FirebaseAuth.getInstance();
        mDB= FirebaseDatabase.getInstance();
        mDBRef = mDB.getReference("Users").child(FirebaseAuth.getInstance().getCurrentUser().getUid());
        //  .setValue(user)

        mDBRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                user1  = dataSnapshot.getValue(User.class);
                arrTrips = user1.TripsArray();

                ArrayList<String> tripEntries = new ArrayList<String>();

                for (int i = 0; i < arrTrips.length; i++)
                {
                    if(arrTrips[i] != null)
                    {
                        tripEntries.add(arrTrips[i].toString());
                    }
                }

                ArrayAdapter adapter = new ArrayAdapter<String>(getApplicationContext(),android.R.layout.simple_list_item_1,tripEntries);
                listRecent.setAdapter(adapter);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                int xy =2;

            }
        });

        listRecent.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String entry = parent.getItemAtPosition(position).toString();
                Trip tripEntry = arrTrips[position];
                Intent intent = new Intent(getApplicationContext(), MapsActivity.class);
                intent.putExtra("position", position);
                startActivity(intent);
            }
        });
    }

}
