package com.example.opsc7312poe_navigation_app;

import java.util.Scanner;

public class User {
    public String getName() {
        return name;
    }

    public void setTrips(String trips)
    {
        this.trips = trips;
    }

    public String getTrips()
    {
        return this.trips;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getMetric() {
        return metric;
    }

    public void setMetric(String metric) {
        this.metric = metric;
    }

    public String getModeTransport() {
        return modeTransport;
    }

    public void setModeTransport(String modeTransport) {
        this.modeTransport = modeTransport;
    }

    public void addTrip(String date, String search, String startLat, String startLon, String stopLat, String stopLon)
    {
        String trip = date + "#" + search + "#" + startLat + "#" + startLon + "#" +stopLat+ "#" + stopLon;
        if (trips == null || trips.length() == 0)
        {
            trips = trip;
        }
        else {
            trips = trips + "," + trip;
        }
    }

    public Trip[] TripsArray()
    {
        Trip[] arrTrips = new Trip[50];
        int count = 0;
        Scanner scMainLine = new Scanner(this.trips).useDelimiter(",");
        while(scMainLine.hasNext())
        {
            String line = scMainLine.next();
            Scanner scLine = new Scanner(line).useDelimiter("#");
            arrTrips[count] = new Trip(scLine.next(), scLine.next(), Double.parseDouble(scLine.next()), Double.parseDouble(scLine.next()), Double.parseDouble(scLine.next()), Double.parseDouble(scLine.next()));
            count++;
        }
        return arrTrips;
    }

    public String name,email,phone,metric,modeTransport,trips;

    public User(){

    }
    public User(String name, String email, String phone,String metric,String modeTransport, String trips) {
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.metric = metric;
        this.modeTransport = modeTransport;
        this.trips = trips;
    }
}
