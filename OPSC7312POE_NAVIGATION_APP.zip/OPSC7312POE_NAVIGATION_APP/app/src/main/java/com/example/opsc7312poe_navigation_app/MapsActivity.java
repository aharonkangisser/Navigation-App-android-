package com.example.opsc7312poe_navigation_app;

import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import com.directions.route.Route;
import com.directions.route.RouteException;
import com.directions.route.Routing;
import com.directions.route.RoutingListener;
import com.firebase.client.Firebase;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.net.PlacesClient;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class MapsActivity extends FragmentActivity implements RoutingListener, OnMapReadyCallback {
    private static final String TAG = MapsActivity.class.getSimpleName();
    private GoogleMap mMap;
    private PlacesClient mPlacesClient;
    private CameraPosition mCameraPosition;
    private FusedLocationProviderClient mFusedLocationProviderClient;
    // A default location (Sydney, Australia) and default zoom to use when location permission is
    // not granted.
    private final LatLng mDefaultLocation = new LatLng(-33.8523341, 151.2106085);
    private static final int DEFAULT_ZOOM = 15;
    private static final int NAVIGATION_ZOOM = 20;
    private static final int PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION = 1;
    private boolean mLocationPermissionGranted;
    // The geographical location where the device is currently located. That is, the last-known
    // location retrieved by the Fused Location Provider.
    private Location mLastKnownLocation;
    private LatLng searchedLatLng;
    private List<Polyline> polylines;
    private static final int[] COLORS = new int[]{R.color.mapboxBlue,R.color.mapboxGrayLight,R.color.mapboxPink,R.color.mapboxRed,R.color.primary_dark_material_light};
    // Keys for storing activity state.
    private static final String KEY_CAMERA_POSITION = "camera_position";
    private static final String KEY_LOCATION = "location";
    private TextView txtNavigationInfo;
    // Used for selecting the current place.
    private static final int M_MAX_ENTRIES = 5;
    private String[] mLikelyPlaceNames;
    private String[] mLikelyPlaceAddresses;
    private List[] mLikelyPlaceAttributions;
    private LatLng[] mLikelyPlaceLatLngs;
    private Button btn_navigation;
    private boolean isNavigating;
    private long startTime = 0;

    Trip trip;
    Trip[] arrTrips;
    private boolean added = false;

    private boolean searchAdded = false;

    private FirebaseAuth mAuth;
    private Firebase mRef;
    private String trips;
    private User user1;
    FirebaseDatabase mDB;
    DatabaseReference mDBRef ;

    DatabaseReference mRootRef = FirebaseDatabase.getInstance().getReference();

    Handler timerHandler = new Handler();
    Runnable timerRunnable = new Runnable() {
        @Override
        public void run() {
            long millis = System.currentTimeMillis() - startTime;

            //Do whatever we want here
            updateRoute();

            timerHandler.postDelayed(this, 500);

        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Retrieve location and camera position from saved instance state.
        timerHandler.removeCallbacks(timerRunnable);
        if (savedInstanceState != null) {
            mLastKnownLocation = savedInstanceState.getParcelable(KEY_LOCATION);
            mCameraPosition = savedInstanceState.getParcelable(KEY_CAMERA_POSITION);
        }

        isNavigating = false;
        polylines = new ArrayList<>();
        setContentView(R.layout.activity_maps);
        // Construct a PlacesClient
        Places.initialize(getApplicationContext(), getString(R.string.google_maps_key));
        mPlacesClient = Places.createClient(this);
        // Construct a FusedLocationProviderClient.
        mFusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
btn_navigation = findViewById(R.id.btn_navigation);
txtNavigationInfo = findViewById(R.id.txtNavigationInfo);

        mAuth = FirebaseAuth.getInstance();
        mDB= FirebaseDatabase.getInstance();
        mDBRef = mDB.getReference("Users").child(FirebaseAuth.getInstance().getCurrentUser().getUid());

        //  .setValue(user)

        mDBRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                user1  = dataSnapshot.getValue(User.class);
                trips = user1.trips;
                arrTrips = user1.TripsArray();

                Bundle extras = getIntent().getExtras();

                if (extras != null && !added)
                {
                    int pos = extras.getInt("position");
                    trip = arrTrips[pos];
                    added = true;

                }

                if (trip != null)
                {
                    mLastKnownLocation = new Location(LocationManager.GPS_PROVIDER);
                    mLastKnownLocation.setLatitude(trip.getStartLatLng().latitude);
                    mLastKnownLocation.setLongitude(trip.getStartLatLng().longitude);
                    searchedLatLng = trip.getStopLatLng();
                    //Set the text of the search field
                    String search = trip.getTripSearch();
                    EditText locationSearch = (EditText) findViewById(R.id.editText);
                    locationSearch.setText(search);

                    updateRoute();

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                int xy =2;

            }
        });







    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap.setInfoWindowAdapter(new GoogleMap.InfoWindowAdapter() {
            @Override
            public View getInfoWindow(Marker marker) {
                return null;
            }

            @Override
            public View getInfoContents(Marker marker) {
                View infoWindow = getLayoutInflater().inflate(R.layout.info_contents, (FrameLayout) findViewById(R.id.map),false);
                TextView title = infoWindow.findViewById(R.id.title);
                title.setText(marker.getTitle());
                TextView snippet = infoWindow.findViewById(R.id.snippet);
                snippet.setText(marker.getSnippet());
                return infoWindow;
            }
        });
        getLocationPermission();
        updateLocationUI();
        getDeviceLocation();
        // Add a marker in Sydney and move the camera
        //LatLng sydney = new LatLng(-34, 151);
        //mMap.addMarker(new MarkerOptions().position(sydney).title("Marker in Sydney"));
        //mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));
    }
    private void getLocationPermission(){
        if (ContextCompat.checkSelfPermission(this.getApplicationContext(),
                android.Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            mLocationPermissionGranted = true;
        } else {
            ActivityCompat.requestPermissions(this,
                    new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION},
                    PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION);
        }
    }
    private void updateLocationUI(){
        if (mMap == null){
            return;
        }
        try {
            if (mLocationPermissionGranted)
            {
                mMap.setMyLocationEnabled(true);
                mMap.getUiSettings().setMyLocationButtonEnabled(true);
            }else{
                mMap.setMyLocationEnabled(false);
                mMap.getUiSettings().setMyLocationButtonEnabled(false);
                mLastKnownLocation = null;
                getLocationPermission();
            }
        }
        catch (SecurityException e)
        {
            Log.e("exception: %s", e.getMessage());
        }
    }
    private void getDeviceLocation(){
        try{
            if (mLocationPermissionGranted)
            {
                Task<Location> locationResult = mFusedLocationProviderClient.getLastLocation();
                locationResult.addOnCompleteListener(this, new OnCompleteListener<Location>() {
                    @Override
                    public void onComplete(@NonNull Task<Location> task) {
                      if (task.isSuccessful())
                      {
                          if (trip == null)
                          {
                              mLastKnownLocation = task.getResult();
                          }

                          if (mLastKnownLocation!=null && !isNavigating)
                          {
                              mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(mLastKnownLocation.getLatitude(), mLastKnownLocation.getLongitude()), DEFAULT_ZOOM));

                          }
                          else if (mLastKnownLocation!= null)
                          {
                              mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(mLastKnownLocation.getLatitude(), mLastKnownLocation.getLongitude()), NAVIGATION_ZOOM));
                          }
                          else{
                              Log.d(TAG,"Current location is null using defaults");
                              Log.e(TAG,"exception: %s", task.getException());
                              mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(mDefaultLocation,DEFAULT_ZOOM));
                              mMap.getUiSettings().setMyLocationButtonEnabled(false);
                          }
                      }
                    }
                });
            }
        }
        catch(SecurityException e){
            Log.e("exception: %s", e.getMessage());
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode,@NonNull String[] permissions,@NonNull int[] grantResults){
        mLocationPermissionGranted = false;
        switch(requestCode){
            case PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION:
            {
                if (grantResults.length>0 && grantResults[0]== PackageManager.PERMISSION_GRANTED)
                {
                    mLocationPermissionGranted = true;
                }
            }
        }
        updateLocationUI();
    }

    public void navigation(View view)
    {
        trip = null;
        if (isNavigating)
        {
            mMap.clear();
            timerHandler.removeCallbacks(timerRunnable);
            btn_navigation.setText("Start Navigation");
            isNavigating = false;
        }
        else
        {
            if (!searchAdded)
            {
                //Save the trip in the Database
                DateFormat df = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
                Date dateobj = new Date();
                EditText locationSearch = (EditText) findViewById(R.id.editText);
                String location = locationSearch.getText().toString();

                String date = df.format(dateobj);
                String startLat = "" + mLastKnownLocation.getLatitude();
                String startLon = "" + mLastKnownLocation.getLongitude();
                String stopLat = "" + searchedLatLng.latitude;
                String stopLon = "" + searchedLatLng.longitude;
                user1.addTrip(date, location, startLat, startLon, stopLat, stopLon);
                User tempUser = new User(
                        user1.name,
                        user1.email,
                        user1.phone,
                        user1.metric,
                        user1.modeTransport,
                        user1.trips
                );
                mDBRef.setValue(tempUser);
                searchAdded =true;

            }



            //mDBRef.setValue(user1);
            mMap.clear();
            isNavigating = true;
            timerHandler.postDelayed(timerRunnable,0);
            btn_navigation.setText("Stop Navigation");
        }

    }



    public void updateRoute()
    {

        if (isNavigating)
        {
            CameraUpdate zoom = CameraUpdateFactory.zoomTo(NAVIGATION_ZOOM);
            mMap.moveCamera(zoom);
        }
        getDeviceLocation();

        if (mLastKnownLocation == null || searchedLatLng == null)
        {
            //Error coding should happen here since you should not be able to call this function if you do not have your location and the marker location
            timerHandler.removeCallbacks(timerRunnable);
            btn_navigation.setText("Start Navigation");
            isNavigating = false;
            return;
        }

        Routing routing = new Routing.Builder().travelMode(Routing.TravelMode.DRIVING).withListener(this)
                .waypoints(new  LatLng(mLastKnownLocation.getLatitude(), mLastKnownLocation.getLongitude()),searchedLatLng).key("AIzaSyBUo345tDOeocerRKPgbv1CHlVCkT3UbDg").build();
        routing.execute();
    }


    public void searchLocation(View view){
        mMap.clear();
        trip = null;
        searchAdded = false;

        getDeviceLocation();
        EditText locationSearch = (EditText) findViewById(R.id.editText);
        String location = locationSearch.getText().toString();
        List<Address> addressList = null;
        if (location!=null|| !location.equals(""))
        {
            Geocoder geocoder = new Geocoder(this);
            try{
                addressList= geocoder.getFromLocationName(location,1);
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }
            if (addressList.size() > 0)
            {
                Address address = addressList.get(0);
                LatLng latLng = new LatLng(address.getLatitude(),address.getLongitude());
                mMap.addMarker(new MarkerOptions().position(latLng).title(location));
                mMap.animateCamera(CameraUpdateFactory.newLatLng(latLng));
                searchedLatLng = latLng;
               // String url = getDirectionsUrl(new  LatLng(mLastKnownLocation.getLatitude(), mLastKnownLocation.getLongitude()), searchedLatLng);
                Routing routing = new Routing.Builder().travelMode(Routing.TravelMode.DRIVING).withListener(this)
                        .waypoints(new  LatLng(mLastKnownLocation.getLatitude(), mLastKnownLocation.getLongitude()),searchedLatLng).key("AIzaSyBUo345tDOeocerRKPgbv1CHlVCkT3UbDg").build();
                routing.execute();
                int x = 1;
            }
            else{
                Toast.makeText(this,"could not find address",Toast.LENGTH_SHORT).show();
                searchedLatLng = null;
            }

        }
    }

    @Override
    public void onRoutingFailure(RouteException e)
    {
        int x = 0;

    }

    @Override
    public void onRoutingStart()
    {
        int y = 0;

    }
public void recenter(View view){
    CameraUpdate center = CameraUpdateFactory.newLatLng(new  LatLng(mLastKnownLocation.getLatitude(), mLastKnownLocation.getLongitude()));
    CameraUpdate zoom = CameraUpdateFactory.zoomTo(20);
    mMap.moveCamera(center);
    mMap.moveCamera(zoom);
}
    @Override
    public void onRoutingSuccess(ArrayList<Route> route,int shortestRouteIndex)
    {
        if (isNavigating)
        {
            CameraUpdate center = CameraUpdateFactory.newLatLng(new  LatLng(mLastKnownLocation.getLatitude(), mLastKnownLocation.getLongitude()));

            CameraUpdate zoom = CameraUpdateFactory.zoomTo(NAVIGATION_ZOOM);
            mMap.moveCamera(center);
            mMap.moveCamera(zoom);
        }
        else
        {
            CameraUpdate center = CameraUpdateFactory.newLatLng(new  LatLng(mLastKnownLocation.getLatitude(), mLastKnownLocation.getLongitude()));
            CameraUpdate zoom = CameraUpdateFactory.zoomTo(16);
            mMap.moveCamera(center);
            mMap.moveCamera(zoom);
        }

        if (polylines.size()>0){
            for (Polyline poly: polylines){
                poly.remove();
            }
        }
        polylines = new ArrayList<>();
        for (int i = 0; i < route.size(); i++){
            int colorIndex = i% COLORS.length;
            PolylineOptions polyOptions = new PolylineOptions();
            polyOptions.color(getResources().getColor(COLORS[colorIndex]));
            polyOptions.width(10 + i * 3);
            polyOptions.addAll(route.get(i).getPoints());
            Polyline polyline = mMap.addPolyline(polyOptions);
            polylines.add(polyline);
             double tempDistance = route.get(i).getDistanceValue();
             int tempTime = route.get(i).getDurationValue()/60;
             String tempDistanceMetric = "M";
             String tempTimeMetric="minutes";
            if (route.get(i).getDistanceValue()> 999 )
            {
                 tempDistance = route.get(i).getDistanceValue()/1000.0;
                 tempDistanceMetric = "km";
            }
            if (tempTime > 60)
            {
                tempTime = (route.get(i).getDurationValue()/60)/60;
                tempTimeMetric = "hours";
            }
            txtNavigationInfo.setText("Distance: "+ tempDistance+tempDistanceMetric + " ETA: " + tempTime+" "+ tempTimeMetric);
         //   Toast.makeText(getApplicationContext(),"Route "+ (i+1) +": distance - "+ route.get(i).getDistanceValue()+ tempDistanceMetric +": duration - "+ route.get(i).getDurationValue()+tempTimeMetric,Toast.LENGTH_SHORT).show();
        }
        MarkerOptions options = new MarkerOptions();
        // Start marker
        if (!isNavigating)
        {
            options.position(new  LatLng(mLastKnownLocation.getLatitude(), mLastKnownLocation.getLongitude()));
            //options.icon(BitmapDescriptorFactory.fromResource(R.drawable.start_blue));
            mMap.addMarker(options);
        }


         // End marker
          options = new MarkerOptions();
          options.position(searchedLatLng);
           //options.icon(BitmapDescriptorFactory.fromResource(R.drawable.end_green));
          mMap.addMarker(options);
    }

    @Override
    public void onRoutingCancelled()
    {
        int z= 0;

    }



}
