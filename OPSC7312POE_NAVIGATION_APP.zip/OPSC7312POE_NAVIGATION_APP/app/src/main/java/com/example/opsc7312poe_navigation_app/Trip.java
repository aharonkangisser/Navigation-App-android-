package com.example.opsc7312poe_navigation_app;

import com.google.android.gms.maps.model.LatLng;

public class Trip {
    private String tripDate;
    private String tripSearch;
    private double startLat;
    private double startLon;
    private double stopLat;
    private double stopLon;

    public Trip(String tripDate, String tripSearch, double startLat, double startLon, double stopLat, double stopLon)
    {
        this.tripDate = tripDate;
        this.tripSearch = tripSearch;
        this.startLat = startLat;
        this.startLon = startLon;
        this.stopLat = stopLat;
        this.stopLon = stopLon;
    }

    public String toString()
    {
        return "Trip Date: " + this.tripDate + " Location: " + this.tripSearch;
    }

    public String getTripDate()
    {
        return this.tripDate;
    }
    public String getTripSearch()
    {
        return this.tripSearch;
    }
    public void setTripDate(String tripDate){
        this.tripDate = tripDate;
    }
    public void setTripSearch(String tripSearch){
        this.tripSearch = tripSearch;
    }

    public LatLng getStartLatLng()
    {
        return new LatLng(this.startLat, this.startLon);
    }
    public LatLng getStopLatLng(){
        return new LatLng(this.stopLat,this.stopLon);
    }
}
