package com.example.opsc7312poe_navigation_app;

import android.Manifest;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.mapbox.mapboxsdk.maps.MapView;

public class MainActivity extends AppCompatActivity implements LocationListener {
    private MapView mapView;
    ImageButton btnMap, btnSaved;
    Switch trafficSwitch;
    Button btnLogout;
    EditText edtProfileEmail, edtProfileName, edtProfileNumber;
    private FirebaseAuth mAuth;
    TextView txtLocation;
    private static final int REQUEST_LOCATION = 123;


    private static final String TAG = "MainActivity";
    private static final int ERROR_DIALOG_REQUEST = 9001;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new HomeFragment()).commit();
        BottomNavigationView bottomNavigationView = findViewById(R.id.btm_nav);
        bottomNavigationView.setSelectedItemId(R.id.nav_home);
        bottomNavigationView.setOnNavigationItemSelectedListener(navListener);
        mAuth = FirebaseAuth.getInstance();
        btnMap = findViewById(R.id.btnMap);
        btnSaved = findViewById(R.id.btnSaved);
        btnLogout = findViewById(R.id.btnLogout);
        edtProfileName = findViewById(R.id.edtEditName);
        edtProfileEmail = findViewById(R.id.edtEditEmail);
        edtProfileNumber = findViewById(R.id.edtEditNumber);
        txtLocation = findViewById(R.id.txtHeadingHome);
        LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);



      //  if (isServicesOK()){
       //     init();
      //  }



        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            ActivityCompat.requestPermissions(this,

                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION,

                            Manifest.permission.ACCESS_COARSE_LOCATION}, REQUEST_LOCATION);
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            //return;
        }


//txtLocation.setText("co-ordinates");
        //  locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        //   locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 10000, 0, this);
    }

    @Override
    public void onLocationChanged(Location location) {

        //  Toast toast =  Toast.makeText(this,"Latitude:" + location.getLatitude() + ", Longitude:" + location.getLongitude(),Toast.LENGTH_SHORT);
        //         toast.show();

        //  txtLocation.setText("Latitude:" + location.getLatitude() + ", Longitude:" + location.getLongitude());
    }

    @Override
    public void onProviderDisabled(String provider) {
        Log.d("Latitude", "disable");
    }

    @Override
    public void onProviderEnabled(String provider) {
        Log.d("Latitude", "enable");
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {
        Log.d("Latitude", "status");
    }

    private BottomNavigationView.OnNavigationItemSelectedListener navListener =
            new BottomNavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                    Fragment selectedFragment = null;
                    switch (item.getItemId()) {
                        case R.id.nav_home:
                            selectedFragment = new HomeFragment();
                            break;
                        case R.id.nav_dashboard:
                            selectedFragment = new DashboardFragment();
                            break;
                        case R.id.nav_profile:
                            selectedFragment = new ProfileFragment();

                            break;
                    }
                    getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, selectedFragment).commit();

                    return true;
                }
            };

    public void logout(View view) {
        FirebaseAuth.getInstance().signOut();//logouts user
        startActivity(new Intent(getApplicationContext(), Login.class));
        finish();
    }


    public void toMap(View view) {
        //Intent intent = new Intent(view.getContext(), activity_map.class);
     //   view.getContext().startActivity(intent);

        Intent intent = new Intent(view.getContext(), MapsActivity.class);
        view.getContext().startActivity(intent);
    }

    public void toHistory(View view) {
        Intent intent = new Intent(MainActivity.this, activity_recent.class);
        startActivity(intent);
    }

    public void toSaved(View view) {
        Intent intent = new Intent(view.getContext(), activity_saved.class);
        view.getContext().startActivity(intent);
    }

    public void showInfo(View view) {


    }
    private void init(){
        ImageButton btnGoogleMap = findViewById(R.id.btnHistory);
        btnGoogleMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, activity_recent.class);
                startActivity(intent);
            }
        });
    }
    public boolean isServicesOK(){
        Log.d(TAG,"isServicesOK: checking google services version");
        int available = GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(MainActivity.this);
        if(available == ConnectionResult.SUCCESS){
            //everything is fine and the user can make map requests
            Log.d(TAG, "isServicesOK: Google play services is working");
            return true;
        }
        else if(GoogleApiAvailability.getInstance().isUserResolvableError(available)){
            // an error occured but we can resolve it
            Log.d(TAG,"isServicesOK: an error occured but we can fix it");
            Dialog dialog = GoogleApiAvailability.getInstance().getErrorDialog(MainActivity.this,available,ERROR_DIALOG_REQUEST);
            dialog.show();
        }
        else{
            Toast.makeText(this,"you can't make map requests",Toast.LENGTH_SHORT).show();
        }
        return false;
    }


}





