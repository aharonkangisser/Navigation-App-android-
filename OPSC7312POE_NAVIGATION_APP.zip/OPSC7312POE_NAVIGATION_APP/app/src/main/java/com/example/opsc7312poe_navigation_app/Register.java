package com.example.opsc7312poe_navigation_app;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.database.FirebaseDatabase;

public class Register extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    EditText edtFullName, edtEmail, edtPassword, edtPhoneNumer;
    Button btnRegister;
    TextView txtToLogin;
    ProgressBar progressBar;
    FirebaseAuth auth;
    Spinner spinMetric, spinMode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        edtFullName = findViewById(R.id.edtName);
        edtEmail = findViewById(R.id.edtEmailLogin);
        edtPassword = findViewById(R.id.edtPasswordLogin);
        btnRegister = findViewById(R.id.btnRegister);
        edtPhoneNumer = findViewById(R.id.edtPhoneNumber);
        txtToLogin = findViewById(R.id.txtToLoginScreen);
        spinMetric = findViewById(R.id.spinMetric);
        spinMode = findViewById(R.id.spinMode);
        auth = FirebaseAuth.getInstance();
        progressBar = findViewById(R.id.progressBar);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.metric, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_item);
        spinMetric.setAdapter(adapter);

        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(this, R.array.modeOfTransport, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_item);
        spinMode.setAdapter(adapter2);

        spinMetric.setOnItemSelectedListener(this);
        spinMode.setOnItemSelectedListener(this);


        if (auth.getCurrentUser() != null) {
            startActivity(new Intent(getApplicationContext(), MainActivity.class));
            finish();
        }

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String email = edtEmail.getText().toString().trim();
                String password = edtPassword.getText().toString().trim();
                final String name = edtFullName.getText().toString();
                final String phoneNumber = edtPhoneNumer.getText().toString();
                final String metric = spinMetric.getSelectedItem().toString();
                final String mode = spinMode.getSelectedItem().toString();


                if (TextUtils.isEmpty(email)) {
                    edtEmail.setError("Email is required.");
                    return;
                }
                if (TextUtils.isEmpty(password)) {
                    edtPassword.setError("Password is required.");
                    return;
                }

                if (password.length() < 6) {
                    edtPassword.setError("Password must be longer than 6 characters.");
                    return;
                }

                progressBar.setVisibility(View.VISIBLE);
                //register user in firebase
                auth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            User user = new User(
                                    name,
                                    email,
                                    phoneNumber,
                                    metric,
                                    mode,
                                    ""
                            );
                            FirebaseDatabase.getInstance().getReference("Users")
                                    .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                    .setValue(user).addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    Toast.makeText(Register.this, "User Created", Toast.LENGTH_LONG).show();
                                    UserProfileChangeRequest profileUpdate = new UserProfileChangeRequest.Builder().setDisplayName(name).build();

                                    auth.getCurrentUser().updateProfile(profileUpdate).addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            startActivity(new Intent(getApplicationContext(), MainActivity.class));
                                            finish();
                                        }
                                    });

                                }
                            });

                        } else {
                            Toast.makeText(Register.this, "Error!" + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                            progressBar.setVisibility(View.GONE);
                        }
                    }
                });

            }
        });
        txtToLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), Login.class));
                finish();
            }
        });
    }


    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

        switch (parent.getId()) { //Run Code For Major Spinner
            case R.id.spinMetric: {
                String text = parent.getItemAtPosition(position).toString();
                String metric = text;// code for first spinner. Depending on spinner.getselecteditem assign adapter to second spinner

              //  Toast.makeText(parent.getContext(), text, Toast.LENGTH_SHORT).show();
            }
            case R.id.spinMode: { // code for second spinner
                //Use get item selected and get selected item position
                String text2 = parent.getItemAtPosition(position).toString();
                String Mode = text2;
                //Toast.makeText(parent.getContext(), text2, Toast.LENGTH_SHORT).show();

            }


            //  Toast.makeText(parent.getContext(), text, Toast.LENGTH_LONG).show();

        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
