package com.example.opsc7312poe_navigation_app;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.firebase.client.Firebase;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class ProfileFragment extends Fragment implements AdapterView.OnItemSelectedListener {

    EditText edtProfileEmail, edtProfileName, edtProfileNumber;
    Spinner spnMetric, spnMode;
    Button btnUpdate;

    private FirebaseAuth mAuth;
    private Firebase mRef;
    private String trips;
    FirebaseDatabase mDB;
    DatabaseReference mDBRef ;

    DatabaseReference mRootRef = FirebaseDatabase.getInstance().getReference();
    DatabaseReference mNameRef = mRootRef.child("phone");

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        return inflater.inflate(R.layout.fragment_profile, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {

        mAuth = FirebaseAuth.getInstance();
        edtProfileName = view.findViewById(R.id.edtEditName);
        edtProfileEmail = view.findViewById(R.id.edtEditEmail);
        edtProfileNumber = view.findViewById(R.id.edtEditNumber);
        spnMetric = view.findViewById(R.id.spinnerMetric);
        spnMode = view.findViewById(R.id.spinnerModeOfTransport);
        btnUpdate = view.findViewById(R.id.btnSave);
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
       // edtProfileName.setText(user.getDisplayName().toString());
      //  edtProfileEmail.setText(user.getEmail().toString());

         mDB= FirebaseDatabase.getInstance();
         mDBRef = mDB.getReference("Users").child(FirebaseAuth.getInstance().getCurrentUser().getUid());
        //  .setValue(user)

        mDBRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                User user1  = dataSnapshot.getValue(User.class);
                edtProfileName.setText(user1.name);
                edtProfileEmail.setText(user1.email);
                edtProfileNumber.setText(user1.phone);
                trips = user1.trips;
                if (user1.metric.equals("mph"))
                {
                    spnMetric.setSelection(1);
                }
                else
                {
                    spnMetric.setSelection(0);
                }
                if (user1.modeTransport.equals("Car"))
                {
                    spnMode.setSelection(0);
                }
                else
                {
                    if (user1.modeTransport.equals("Walk"))
                {
                    spnMode.setSelection(1);
                }
                    else
                    {
                        spnMode.setSelection(2);
                    }
                }
                    int x =1;
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                int xy =2;

            }
        });




        spnMetric.setOnItemSelectedListener(this);
        spnMode.setOnItemSelectedListener(this);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(view.getContext(), R.array.metric, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_item);
        spnMetric.setAdapter(adapter);

        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(view.getContext(), R.array.modeOfTransport, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_item);
        spnMode.setAdapter(adapter2);
        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                UpdateProfile();
            }
        });

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        switch (parent.getId()) { //Run Code For Major Spinner
            case R.id.spinnerMetric: {
                String text = parent.getItemAtPosition(position).toString();
                String metric = text;// code for first spinner. Depending on spinner.getselecteditem assign adapter to second spinner

                //Toast.makeText(parent.getContext(), text, Toast.LENGTH_SHORT).show();
            }
            case R.id.spinnerModeOfTransport: { // code for second spinner
                //Use get item selected and get selected item position
                String text2 = parent.getItemAtPosition(position).toString();
                String Mode = text2;
                //Toast.makeText(parent.getContext(), text2, Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    public void UpdateProfile() {

        String name = edtProfileName.getText().toString();
        String email = edtProfileEmail.getText().toString();
        String phone = edtProfileNumber.getText().toString();
        String metric = spnMetric.getSelectedItem().toString();
        String mode = spnMode.getSelectedItem().toString();

        //<date>#<searchstring>#<lat1>#<long1>#<lat2>#<long2>,<date>#<searchstring>#<lat1>#<long1>#<lat2>#<long2>,<date>#<searchstring>#<lat1>#<long1>#<lat2>#<long2>

        //Scanner scLine = new Scanner("Test");

        User tempUser = new User(
                name,
                email,
                phone,
                metric,
                mode,
                trips
        );
        mDBRef.setValue(tempUser);

/*
            mNameRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    String TextName = dataSnapshot.getValue(String.class);
                    edtProfileName.setText(TextName);
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
    }*/
    }
}